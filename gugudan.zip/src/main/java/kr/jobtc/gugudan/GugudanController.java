package kr.jobtc.gugudan;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GugudanController {
    @PostMapping("/gugudan")
    public Map<String, String> gugudan(@RequestBody Map<String, Integer> map){
        Map<String, String> result = new HashMap<>();
        int dan = map.get("dan");
        Gugudan g = new Gugudan();
        String temp = g.process(dan);
        result.put("result", temp);
        return result;
    }
    
}
