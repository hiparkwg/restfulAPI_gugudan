package kr.jobtc.gugudan;

public class Gugudan {

    public String process(int dan){
        String result = ""; //StringBuffer, StringBuilder
        int i=0;
        int r=0; //dan*i

        for(i=1; i<=9 ; i++){
            r=dan*i;
            result += String.format("%s * %s = %s\n", dan, i, r);
        }
        return result;

    }

    public static void main(String[] args) {
       Gugudan g = new Gugudan();
       String result = g.process(7);
        System.out.println(result);

    }
}
