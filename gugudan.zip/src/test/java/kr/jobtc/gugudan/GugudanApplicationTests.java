package kr.jobtc.gugudan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GugudanApplicationTests {

	@Test
	void contextLoads() {
	}

}
